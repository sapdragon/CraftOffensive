#include "../events.h"

void events::player_hurt(i_game_event* event) {

}