#pragma once

class i_surface {
public:
	VFUNC(unlock_cursor(), 66, void(__thiscall*)(void*))
	VFUNC(lock_cursor(), 67, void(__thiscall*)(void*))
};