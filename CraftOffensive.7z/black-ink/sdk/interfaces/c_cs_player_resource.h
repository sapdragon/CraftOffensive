#pragma once

class i_cs_player_resource {
public:
	NETVAR(m_player_c4(), int, "CCSPlayerResource->m_iPlayerC4")
};