#pragma once

class i_mdl_cache {
public:
	VFUNC(lock(), 33, void(__thiscall*)(void*))
	VFUNC(unlock(), 34, void(__thiscall*)(void*))
};
